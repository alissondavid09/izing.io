#!/bin/bash
#
# Variables to be used for background styling.

# app variables

jwt_secret=DPHmNRZWZ4isLF9vXkMv1QabvpcA80Rc
jwt_refresh_secret=EMPehEbrAdi7s8fGSeYzqGQbV5wrjH4i

#deploy_password=password

#redis_pass=password

#postgres_root_password=password

#db_pass=password

#db_user=izing
#db_name=izing

deploy_email=lumardyelson@gmail.com
