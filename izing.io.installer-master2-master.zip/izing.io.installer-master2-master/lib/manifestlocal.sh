#!/bin/bash

source "${PROJECT_ROOT}"/lib/_backend.sh
source "${PROJECT_ROOT}"/lib/_frontend.sh
source "${PROJECT_ROOT}"/lib/_systemlocal.sh
source "${PROJECT_ROOT}"/lib/_inquirylocal.sh
source "${PROJECT_ROOT}"/lib/_adminfrontend.sh

